#!/bin/bash
cd classes
java -cp .:../jar/* cloud.Driver
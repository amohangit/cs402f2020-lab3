#!/bin/sh
javac -d classes src/*.java

import java.util.Random;
import java.util.Scanner;
public class Processor{
	public static void output(String fileName, int op){
        /*
        Data is prepared by outputting the final result. 
        */
        FileUtility words = new FileUtility(fileName);
        words.write("Total Word count(b):" + Integer.toString(op));
        words.reset();
       
    }
    public static void count(String fileName){
        FileUtility words = new FileUtility(fileName);
        int size = words.size();
        output("../data/output_b.txt",size);
        
    }
	public static void main(String[] args){
		count("../data/words1.txt");
	}
}
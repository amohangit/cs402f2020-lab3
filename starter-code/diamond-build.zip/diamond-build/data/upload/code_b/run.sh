#!/bin/sh
cd classes
java Processor


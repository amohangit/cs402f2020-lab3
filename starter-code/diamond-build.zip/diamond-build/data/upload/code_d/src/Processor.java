import java.util.Random;
import java.util.Scanner;
public class Processor{
	public static void output(String fileName, int count, int file_id){
        /*
        Data is prepared by outputting the final result. 
        */
        FileUtility words = new FileUtility(fileName);
        words.write("File " + file_id + " has more words, and the count is: " + count);
        words.reset();
       
    }
    public static void read(String fileName1, String fileName2){
        FileUtility words1 = new FileUtility(fileName1);
        int size1 = words1.size();
        String line1 = words1.read(); 
        line1 = line1.substring(line1.lastIndexOf(":") + 2, line1.length());
        int count1 = Integer.parseInt(line1);
        words1.reset();

        FileUtility words2 = new FileUtility(fileName2);
        int size2 = words2.size();
        String line2 = words2.read(); 
        line2 = line2.substring(line2.lastIndexOf(":") + 2, line2.length());
        int count2 = Integer.parseInt(line2);
        words2.reset();
        /* find max */
        int file_id  = 1, res = count1;
        if (count1 < count2){
            res = count2;
            file_id = 2;
        }
        output("../data/output_d.txt",res, file_id );
        
    }
	public static void main(String[] args){
		read("../data/output_b.txt", "../data/output_c.txt");
	}
}
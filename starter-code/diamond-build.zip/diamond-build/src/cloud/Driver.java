/*
    Code developed for CMPSC 402 class 
    by Professor. Mohan using the Jsch Library.
    This class provides the methods such as running shell commands on remote machines, 
    copying data from one machine to another, etc.
*/
package cloud;
import java.util.ArrayList;
import org.w3c.dom.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.*;

public class Driver{
    private static String host_b = "";
    private static String host_c = "";
    private static String host_d = "";
    private static String pem_b = "";
    private static String pem_c = "";
    private static String user = "";
    private static int port = 0;
    private static String upload_b_src = "";
    private static String upload_c_src = "";
    private static String upload_d_src = "";
    private static String upload_dest = "";
    private static String download_b_src = "";
    private static String download_c_src = "";
    private static String download_d_src = "";
    private static String download_dest = "";

    public static String prefix(String add){
       String path = System.getProperty("user.dir");
        if (path.indexOf("\\") >= 0){
            path = path.substring(0, path.lastIndexOf("\\") + 1);
            add.replaceAll("\\", "\\\\");
        }
        else if (path.indexOf("/") >= 0){
            path = path.substring(0, path.lastIndexOf("/") + 1);
        }
        path = path + add;
        return path;
    }
    public static void loadconfig(){
        try{
            Shell sh = new Shell();
            String pathToConfig = prefix("data/config.xml");
            String pathToPem = prefix("data/");
            String pathToUpload = prefix("data/upload/");

            Document config = Utility.readFileAsDocument(pathToConfig);
            host_b = ((Element) config.getDocumentElement().getElementsByTagName("host_b").item(0)).getTextContent().trim();
            host_c = ((Element) config.getDocumentElement().getElementsByTagName("host_c").item(0)).getTextContent().trim();
            host_d = ((Element) config.getDocumentElement().getElementsByTagName("host_d").item(0)).getTextContent().trim();
            upload_b_src = pathToUpload + ((Element) config.getDocumentElement().getElementsByTagName("upload_b_src").item(0)).getTextContent().trim();
            upload_c_src = pathToUpload + ((Element) config.getDocumentElement().getElementsByTagName("upload_c_src").item(0)).getTextContent().trim();
            upload_d_src = pathToUpload +  ((Element) config.getDocumentElement().getElementsByTagName("upload_d_src").item(0)).getTextContent().trim();
            upload_dest = ((Element) config.getDocumentElement().getElementsByTagName("upload_dest").item(0)).getTextContent().trim();
            download_b_src = ((Element) config.getDocumentElement().getElementsByTagName("download_b_src").item(0)).getTextContent().trim();
            download_c_src = ((Element) config.getDocumentElement().getElementsByTagName("download_c_src").item(0)).getTextContent().trim();
            download_d_src = ((Element) config.getDocumentElement().getElementsByTagName("download_d_src").item(0)).getTextContent().trim();
            download_dest = ((Element) config.getDocumentElement().getElementsByTagName("download_dest").item(0)).getTextContent().trim();
            user = ((Element) config.getDocumentElement().getElementsByTagName("user").item(0)).getTextContent().trim();
            pem_b = pathToPem + ((Element) config.getDocumentElement().getElementsByTagName("pem_b").item(0)).getTextContent().trim();
            pem_c = pathToPem + ((Element) config.getDocumentElement().getElementsByTagName("pem_c").item(0)).getTextContent().trim();
            port = Integer.parseInt(((Element) config.getDocumentElement().getElementsByTagName("port").item(0)).getTextContent().trim());
            
        }
        catch (Exception ex){
            System.out.println(ex.toString());
        }
        
    }
    public static void start_uploads(){
        long start_time = System.nanoTime();
        try{
            Upload up = new Upload();
            ExecutorService threadPool = Executors.newFixedThreadPool(3);
            for (int node = 0; node < 3; node++) {
               threadPool.submit(new Runnable() {
                    public void run(){ 
                        long threadId = Thread.currentThread().getId(); 
                        if (threadId % 12 == 0)
                            up.uploader(upload_b_src, upload_dest, host_b, user, pem_b, port); 
                        else if (threadId % 12 == 1)
                            up.uploader(upload_c_src, upload_dest, host_c, user, pem_c, port); 
                        else if (threadId % 12 == 2)
                            up.uploader(upload_d_src, upload_dest, host_d, user, pem_c, port); 

                        //System.out.println(threadId + "\t" + first + "\t" + last);
                    }
                });
            }
            threadPool.shutdown();  
            while(true) {
                if(threadPool.isTerminated()) {
                    System.out.println("#Completed uploading...");
                    long end_time = System.nanoTime();
                    long total_time = end_time - start_time;
                    System.out.println("Total time taken:" + total_time);
                    break;
                }
            }
        }
        catch(Exception ex){
            System.out.println(ex.toString());
        }
    }
    public static void start_execute(){
        /* complete implementation here .... */
    }
    public static void start_downloads(){
        /* complete implementation here .... */
    }

    public static void main(String[] args) throws Exception, InterruptedException{
        loadconfig();
        start_uploads();
        /* start_execute and start_download here ... */

    }
}    
    



package cloud;
import java.util.Date;
import java.util.concurrent.*;
class Upload{
	void uploader(String src, String dest, String host, String user, String pem, int port){
		try{
			Shell sh = new Shell();
			sh.upload(src, dest, host, user, pem, port);		
			System.out.println("#upload to " + host + " success.");
		}
		catch(Exception ex){
			System.out.println(ex.toString());
		}
	}
}
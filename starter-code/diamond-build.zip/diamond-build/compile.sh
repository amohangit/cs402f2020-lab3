#!/bin/bash
javac -d "classes" -cp ".:jar/*" src/cloud/*.java